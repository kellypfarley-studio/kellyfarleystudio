import { useMemo, useRef } from "react";
import type { Anchor, DepthLayer, PaletteColor, ProjectSpecs, Strand, ViewTransform, Swoop } from "../types/appTypes";
import type { Ref } from "react";
import PanelFrame from "../components/PanelFrame";
import ViewControls from "../components/ViewControls";
import { computeStrandPreview, SPHERE_PITCH_IN, SPHERE_RADIUS_IN } from "../utils/previewGeometry";
import { projectPreview, computeYShift } from "../utils/rotationProjection";

export function computePreviewFitBounds(specs: ProjectSpecs, strands: Strand[], anchors: Anchor[], swoops: Swoop[] = []) {
  const previews = strands.map((s) => {
    const a = anchors.find((x) => x.id === s.anchorId) ?? null;
    const pv = computeStrandPreview(specs, s.spec);
    return { strand: s, anchor: a, pv };
  });

  const r = SPHERE_RADIUS_IN;
  const padX = r + 2;
  const padTop = 2;
  const padBottom = 12;

  let maxDrop = specs.ceilingHeightIn;
  for (const p of previews) {
    maxDrop = Math.max(maxDrop, p.pv.totalDropIn);
  }

  // consider swoops: their deepest point is roughly midpoint + sag
  for (const s of swoops) {
    const ctrlY = (s.spec.chainAIn + s.spec.chainBIn) / 2 + s.spec.sagIn;
    maxDrop = Math.max(maxDrop, ctrlY);
  }

  const minX = -padX;
  const maxX = specs.boundaryWidthIn + padX;
  const minY = -padTop;
  const maxY = maxDrop + padBottom;
  return { minX, maxX, minY, maxY, w: maxX - minX, h: maxY - minY };
}

export type FrontPreviewPanelProps = {
  specs: ProjectSpecs;
  view: ViewTransform;
  onViewChange: (next: ViewTransform) => void;
  svgRef?: Ref<SVGSVGElement>;

  anchors: Anchor[];
  strands: Strand[];
  swoops?: Swoop[];
  palette: PaletteColor[];
  selectedAnchorId: string | null;
  panEnabled?: boolean;
  onTogglePan?: () => void;
  previewView?: ProjectSpecs["previewView"];
  onPreviewDepthPatch?: (patch: Partial<ProjectSpecs["previewDepth"]>) => void;
  onPreviewViewPatch?: (patch: Partial<ProjectSpecs["previewView"]>) => void;
};

function clientToSvgCoords(svg: SVGSVGElement, clientX: number, clientY: number): { x: number; y: number } {
  const pt = svg.createSVGPoint();
  pt.x = clientX;
  pt.y = clientY;
  const ctm = svg.getScreenCTM?.();
  if (!ctm) return { x: 0, y: 0 };
  const svgP = pt.matrixTransform(ctm.inverse());
  return { x: svgP.x, y: svgP.y };
}

function colorHex(palette: PaletteColor[], id: string): string {
  return palette.find((c) => c.id === id)?.hex ?? "#111";
}

function layerOpacity(layer: string): number {
  if (layer === "front") return 1.0;
  if (layer === "mid") return 0.7;
  return 0.45;
}

type Pt = { x: number; y: number };

function buildHangingPolyline(
  p0: Pt,
  p1: Pt,
  totalLength: number,
  pointCount: number,
  iterations: number = 90,
): { pts: Pt[]; cum: number[] } {
  const n = Math.max(2, Math.floor(pointCount));
  const L = Math.max(0, totalLength);
  const segLen = n > 1 ? L / (n - 1) : 0;

  // Seed points on a gently sagging curve so the relaxation converges quickly.
  const pts: Pt[] = new Array(n);
  for (let i = 0; i < n; i += 1) {
    const t = n === 1 ? 0 : i / (n - 1);
    const x = p0.x + (p1.x - p0.x) * t;
    const y = p0.y + (p1.y - p0.y) * t + Math.sin(Math.PI * t) * 0.25 * segLen;
    pts[i] = { x, y };
  }
  // Pin endpoints
  pts[0].x = p0.x;
  pts[0].y = p0.y;
  pts[n - 1].x = p1.x;
  pts[n - 1].y = p1.y;

  if (segLen > 0) {
    const g = 0.35; // visual gravity; larger = more sag for the same slack
    const constraintPasses = 6;
    for (let iter = 0; iter < iterations; iter += 1) {
      // Apply gravity to internal points
      for (let i = 1; i < n - 1; i += 1) {
        pts[i].y += g;
      }

      // Satisfy distance constraints
      for (let pass = 0; pass < constraintPasses; pass += 1) {
        for (let i = 0; i < n - 1; i += 1) {
          const p = pts[i];
          const q = pts[i + 1];
          const dx = q.x - p.x;
          const dy = q.y - p.y;
          const dist = Math.hypot(dx, dy) || 1e-9;
          const diff = (dist - segLen) / dist;

          // Split correction between the two points unless it's an endpoint.
          const wP = i === 0 ? 0 : 0.5;
          const wQ = i + 1 === n - 1 ? 0 : 0.5;
          const wSum = wP + wQ;
          if (wSum <= 0) continue;

          const corrX = dx * diff;
          const corrY = dy * diff;
          if (wP > 0) {
            p.x += corrX * (wP / wSum);
            p.y += corrY * (wP / wSum);
          }
          if (wQ > 0) {
            q.x -= corrX * (wQ / wSum);
            q.y -= corrY * (wQ / wSum);
          }
        }

        // Re-pin endpoints each pass
        pts[0].x = p0.x;
        pts[0].y = p0.y;
        pts[n - 1].x = p1.x;
        pts[n - 1].y = p1.y;
      }
    }
  }

  // Cumulative arc-length table for sampling
  const cum: number[] = new Array(n);
  cum[0] = 0;
  for (let i = 1; i < n; i += 1) {
    const dx = pts[i].x - pts[i - 1].x;
    const dy = pts[i].y - pts[i - 1].y;
    cum[i] = cum[i - 1] + Math.hypot(dx, dy);
  }
  return { pts, cum };
}

function samplePolyline(pts: Pt[], cum: number[], s: number): Pt {
  if (pts.length === 0) return { x: 0, y: 0 };
  if (pts.length === 1) return { ...pts[0] };
  const total = cum[cum.length - 1] ?? 0;
  const target = Math.max(0, Math.min(total, s));
  // Linear scan is fine here (small point count)
  let i = 1;
  while (i < cum.length && cum[i] < target) i += 1;
  if (i >= cum.length) return { ...pts[pts.length - 1] };
  const s0 = cum[i - 1];
  const s1 = cum[i];
  const t = s1 - s0 <= 1e-9 ? 0 : (target - s0) / (s1 - s0);
  return {
    x: pts[i - 1].x + (pts[i].x - pts[i - 1].x) * t,
    y: pts[i - 1].y + (pts[i].y - pts[i - 1].y) * t,
  };
}

export default function FrontPreviewPanel(props: FrontPreviewPanelProps) {
  const { specs, view } = props;
  const { svgRef: svgRefProp } = props as any;
  const svgRef = useRef<SVGSVGElement | null>(null);
  const setSvgRef = (el: SVGSVGElement | null) => {
    svgRef.current = el;
    if (!svgRefProp) return;
    if (typeof svgRefProp === "function") {
      try {
        (svgRefProp as any)(el);
      } catch (_) {}
    } else {
      try {
        (svgRefProp as any).current = el;
      } catch (_) {}
    }
  };

  const panRef = useRef<{ active: boolean; start: { x: number; y: number }; initPan: { x: number; y: number } }>({ active: false, start: { x: 0, y: 0 }, initPan: { x: 0, y: 0 } });

  const anchorById = useMemo(() => {
    const m = new Map<string, Anchor>();
    for (const a of props.anchors) m.set(a.id, a);
    return m;
  }, [props.anchors]);

  const previews = useMemo(() => {
    return props.strands.map((s) => {
      const a = anchorById.get(s.anchorId);
      const pv = computeStrandPreview(specs, s.spec);
      return { strand: s, anchor: a ?? null, pv };
    });
  }, [anchorById, props.strands, specs]);

  const swoopPreviews = useMemo(() => {
    return (props.swoops ?? []).map((sw) => {
      const a = anchorById.get(sw.aHoleId) ?? null;
      const b = anchorById.get(sw.bHoleId) ?? null;
      return { swoop: sw, a, b };
    });
  }, [anchorById, props.swoops]);

  const bounds = useMemo(() => {
    const r = SPHERE_RADIUS_IN;
    const padX = r + 2;
    const padTop = 2;
    const padBottom = 12;

    let maxDrop = specs.ceilingHeightIn;
    for (const p of previews) {
      maxDrop = Math.max(maxDrop, p.pv.totalDropIn);
    }
    for (const s of swoopPreviews) {
      const ctrl = (s.swoop.spec.chainAIn + s.swoop.spec.chainBIn) / 2 + s.swoop.spec.sagIn;
      maxDrop = Math.max(maxDrop, ctrl);
    }

    const minX = -padX;
    const maxX = specs.boundaryWidthIn + padX;
    const minY = -padTop;
    const maxY = maxDrop + padBottom;
    return { minX, maxX, minY, maxY, w: maxX - minX, h: maxY - minY };
  }, [previews, swoopPreviews, specs.boundaryWidthIn, specs.ceilingHeightIn]);

  // Camera
  const viewZoom = Math.max(0.0001, view.zoom);
  const viewW = bounds.w / viewZoom;
  const viewH = bounds.h / viewZoom;
  const centerX = (bounds.minX + bounds.maxX) / 2 + (view.panX || 0);
  const centerY = (bounds.minY + bounds.maxY) / 2 + (view.panY || 0);
  const vbX = centerX - viewW / 2;
  const vbY = centerY - viewH / 2;
  const vbW = viewW;
  const vbH = viewH;

  const left = (
    <ViewControls
      view={view}
      onChange={props.onViewChange}
      onFit={() => props.onViewChange({ zoom: 1, panX: 0, panY: 0 })}
      panEnabled={props.panEnabled}
      onTogglePan={props.onTogglePan}
    />
  );

  const centerControls = (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div className="field" style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span className="smallLabel">Perspective</span>
        <input
          type="range"
          min={-1}
          max={1}
          step={0.05}
          value={props.specs.previewDepth?.perspectiveFactor ?? 0}
          onChange={(e) => props.onPreviewDepthPatch?.({ perspectiveFactor: Number(e.target.value) })}
          style={{ width: 120 }}
        />
        <input
          type="number"
          value={props.specs.previewDepth?.perspectiveFactor ?? 0}
          step={0.05}
          onChange={(e) => props.onPreviewDepthPatch?.({ perspectiveFactor: Number(e.target.value) })}
          style={{ width: 56 }}
        />
      </div>

      <div className="field" style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span className="smallLabel">Preview</span>
        <input
          type="range"
          min={0}
          max={360}
          step={5}
          value={props.previewView?.rotationDeg ?? 0}
          onChange={(e) => props.onPreviewViewPatch?.({ rotationDeg: Number(e.target.value) })}
          style={{ width: 140 }}
        />
        <input
          type="number"
          value={props.previewView?.rotationDeg ?? 0}
          onChange={(e) => props.onPreviewViewPatch?.({ rotationDeg: Number(e.target.value) })}
          style={{ width: 56 }}
        />
        <div style={{ display: "flex", gap: 6, marginLeft: 6 }}>
          <button className="btn" onClick={() => props.onPreviewViewPatch?.({ rotationDeg: 0 })}>Front</button>
          <button className="btn" onClick={() => props.onPreviewViewPatch?.({ rotationDeg: 180 })}>Back</button>
        </div>
      </div>
    </div>
  );

  return (
    <PanelFrame
      title="Preview"
      headerHint={<span className="muted">Read-only preview (generated from Plan View)</span>}
      left={left}
      center={centerControls}
    >
      <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
        <svg
          ref={setSvgRef}
          width="100%"
          height="100%"
          viewBox={`${vbX} ${vbY} ${vbW} ${vbH}`}
          preserveAspectRatio="xMidYMid meet"
          style={{ background: "#fff", touchAction: "none", cursor: props.panEnabled ? "grab" : undefined }}
          onPointerDown={(ev) => {
            if (!props.panEnabled) return;
            ev.preventDefault();
            const svg = svgRef.current;
            if (!svg) return;
            const start = clientToSvgCoords(svg, ev.clientX, ev.clientY);
            panRef.current.active = true;
            panRef.current.start = start;
            panRef.current.initPan = { x: props.view.panX || 0, y: props.view.panY || 0 };

            const onMove = (mev: PointerEvent) => {
              if (!panRef.current.active) return;
              const cur = clientToSvgCoords(svg, mev.clientX, mev.clientY);
              const dx = panRef.current.start.x - cur.x;
              const dy = panRef.current.start.y - cur.y;
              props.onViewChange({ zoom: props.view.zoom, panX: panRef.current.initPan.x + dx, panY: panRef.current.initPan.y + dy });
            };

            const onUp = () => {
              panRef.current.active = false;
              window.removeEventListener('pointermove', onMove);
              window.removeEventListener('pointerup', onUp);
              try {
                if (svg) svg.style.cursor = props.panEnabled ? "grab" : "default";
              } catch (_) {}
            };

            window.addEventListener('pointermove', onMove);
            window.addEventListener('pointerup', onUp);
            (ev.target as Element).setPointerCapture(ev.pointerId);
            try {
              svg.style.cursor = "grabbing";
            } catch (_) {}
          }}
        >
          {/* Ceiling and floor */}
          <line x1={0} y1={0} x2={specs.boundaryWidthIn} y2={0} stroke="#111" strokeWidth={0.08} />
          <line x1={0} y1={specs.ceilingHeightIn} x2={specs.boundaryWidthIn} y2={specs.ceilingHeightIn} stroke="#111" strokeWidth={0.08} />

          {/* Strands */}
          <g>
            {(() => {
              const pvView = props.previewView ?? specs.previewView ?? { rotationDeg: 0, rotationStrength: 1 };
              // map previews to include projection
              const mapped = previews.map((p) => {
                if (!p.anchor) return { ...p, proj: null };
                const proj = projectPreview(specs, p.anchor, pvView.rotationDeg, pvView.rotationStrength);
                return { ...p, proj };
              });
              // sort by depthKey ascending so farther items draw first
              // tie-break with layer priority so front-layer strands draw on top in Front view
              const layerPriority = (layer?: string) => (layer === "front" ? 2 : layer === "mid" ? 1 : 0);
              // sort by depthKey descending so nearer items draw last (on top)
              const sorted = mapped.sort((a, b) => {
                const ka = a.proj?.depthKey ?? 0;
                const kb = b.proj?.depthKey ?? 0;
                if (ka !== kb) return kb - ka;
                const la = a.strand?.spec.layer ?? "mid";
                const lb = b.strand?.spec.layer ?? "mid";
                return layerPriority(la) - layerPriority(lb);
              });

              return sorted.map(({ strand, anchor, pv, proj }) => {
                if (!anchor || !proj) return null;
                const sx = proj.xIn;
                const perspective = specs.previewDepth?.perspectiveFactor ?? 0;
                const yShift = computeYShift(specs, proj.depthKey, perspective);

                const col = colorHex(props.palette, strand.spec.colorId);
                const op = layerOpacity(strand.spec.layer);
                const isSelected = anchor.id === props.selectedAnchorId;

                const sphereR = SPHERE_RADIUS_IN;
                const strokeW = isSelected ? 0.18 : 0.10;

                return (
                  <g key={strand.id} opacity={op}>
                    <line
                      x1={sx}
                      y1={pv.topChainY1 - yShift}
                      x2={sx}
                      y2={pv.topChainY2 - yShift}
                      stroke={isSelected ? "#ff6666" : "#111"}
                      strokeWidth={strokeW}
                      strokeDasharray="0.25 0.25"
                    />

                    {/* Spheres */}
                    {pv.sphereCentersY.map((cy, idx) => (
                      <circle key={idx} cx={sx} cy={cy - yShift} r={sphereR} fill={col} stroke={isSelected ? "#ff6666" : "#111"} strokeWidth={strokeW} />
                    ))}

                    <line
                      x1={sx}
                      y1={pv.bottomChainY1 - yShift}
                      x2={sx}
                      y2={pv.bottomChainY2 - yShift}
                      stroke={isSelected ? "#ff6666" : "#111"}
                      strokeWidth={strokeW}
                      strokeDasharray="0.25 0.25"
                    />

                    {strand.spec.moundPreset !== "none" ? (
                      <path
                        d={`
                      M ${sx - 2} ${specs.ceilingHeightIn + 2}
                      C ${sx - 1} ${specs.ceilingHeightIn + 0.5}, ${sx + 1} ${specs.ceilingHeightIn + 3.0}, ${sx + 2} ${
                          specs.ceilingHeightIn + 2
                        }
                      C ${sx + 1} ${specs.ceilingHeightIn + 4.0}, ${sx - 1} ${specs.ceilingHeightIn + 4.0}, ${sx - 2} ${
                          specs.ceilingHeightIn + 2
                        }
                      Z
                    `}
                        fill="#111"
                        opacity={0.9}
                      />
                    ) : null}

                    {pv.overCeiling ? (
                      <text x={sx + 1.0} y={specs.ceilingHeightIn - 1.0} fontSize={2.5} fill="#ff6666">
                        !
                      </text>
                    ) : null}
                  </g>
                );
              });
            })()}
          </g>

          {/* Swoops */}
          <g>
            {swoopPreviews.map((sp) => {
              if (!sp.a || !sp.b) return null;
              const pvView = props.previewView ?? specs.previewView ?? { rotationDeg: 0, rotationStrength: 1 };
              const pa = projectPreview(specs, sp.a, pvView.rotationDeg, pvView.rotationStrength);
              const pb = projectPreview(specs, sp.b, pvView.rotationDeg, pvView.rotationStrength);
              const xA = pa.xIn;
              const xB = pb.xIn;

              // Endpoints are the bottoms of the end chains (where the first/last sphere centers sit).
              const yA = Math.max(0, sp.swoop.spec.chainAIn || 0);
              const yB = Math.max(0, sp.swoop.spec.chainBIn || 0);

              const perspective = specs.previewDepth?.perspectiveFactor ?? 0;

              // Let a swoop render across different plan depths if endpoints have different strand layers.
              const layerFor = (holeId: string): DepthLayer => {
                const st = props.strands.find((s) => s.anchorId === holeId);
                return (st?.spec.layer as DepthLayer) ?? "mid";
              };
              const layerShift = (layer: DepthLayer): number => {
                const spread = specs.previewDepth?.layerSpreadIn ?? 0;
                if (layer === "front") return -spread;
                if (layer === "back") return spread;
                return 0;
              };
              const depthA = pa.depthKey + layerShift(layerFor(sp.swoop.aHoleId));
              const depthB = pb.depthKey + layerShift(layerFor(sp.swoop.bHoleId));
              const yShiftAt = (t: number) => computeYShift(specs, depthA + (depthB - depthA) * t, perspective);

              const col = colorHex(props.palette, sp.swoop.spec.colorId ?? "");
              const strokeW = 0.12;
              const sphereR = SPHERE_RADIUS_IN;
              const sphereCount = Math.max(0, Math.floor(sp.swoop.spec.sphereCount || 0));

              // Interpret sagIn as extra slack (in inches) to drape deeper.
              const slackIn = Math.max(0, sp.swoop.spec.sagIn || 0);
              const baseLen = sphereCount <= 1 ? 0 : (sphereCount - 1) * SPHERE_PITCH_IN;
              const endDist = Math.hypot(xB - xA, yB - yA);
              const L = Math.max(endDist + 0.001, baseLen + slackIn);

              const pointCount = Math.max(40, Math.min(160, sphereCount * 12));
              const { pts, cum } = buildHangingPolyline({ x: xA, y: yA }, { x: xB, y: yB }, L, pointCount);

              // Build the chain path (apply depth shift per point along arc length)
              const d = pts
                .map((p, i) => {
                  const t = L > 0 ? Math.min(1, Math.max(0, cum[i] / L)) : 0;
                  const y = p.y - yShiftAt(t);
                  return `${i === 0 ? "M" : "L"} ${p.x.toFixed(3)} ${y.toFixed(3)}`;
                })
                .join(" ");

              const yShiftA = yShiftAt(0);
              const yShiftB = yShiftAt(1);

              // Sample sphere centers at equal arc-length steps along the chain.
              const sphereEls: any[] = [];
              if (sphereCount === 1) {
                const mid = samplePolylineAtLength(pts, cum, L / 2);
                const t = 0.5;
                sphereEls.push(
                  <circle
                    key={`sp-${sp.swoop.id}-0`}
                    cx={mid.x}
                    cy={mid.y - yShiftAt(t)}
                    r={sphereR}
                    fill={col}
                    stroke="#111"
                    strokeWidth={0.08}
                  />,
                );
              } else if (sphereCount > 1) {
                for (let i = 0; i < sphereCount; i++) {
                  const sLen = (L * i) / (sphereCount - 1);
                  const t = L > 0 ? sLen / L : 0;
                  const p = samplePolylineAtLength(pts, cum, sLen);
                  sphereEls.push(
                    <circle
                      key={`sp-${sp.swoop.id}-${i}`}
                      cx={p.x}
                      cy={p.y - yShiftAt(t)}
                      r={sphereR}
                      fill={col}
                      stroke="#111"
                      strokeWidth={0.08}
                    />,
                  );
                }
              }

              return (
                <g key={`swoop-${sp.swoop.id}`} opacity={1}>
                  {/* end chains */}
                  <line x1={xA} y1={0 - yShiftA} x2={xA} y2={yA - yShiftA} stroke="#111" strokeWidth={0.1} strokeDasharray="0.25 0.25" />
                  <line x1={xB} y1={0 - yShiftB} x2={xB} y2={yB - yShiftB} stroke="#111" strokeWidth={0.1} strokeDasharray="0.25 0.25" />

                  {/* catenary-ish chain */}
                  <path d={d} stroke={col} strokeWidth={strokeW} fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  {sphereEls}
                </g>
              );
            })}
          </g>
        </svg>

        {/* separator: adjusts --previewH (bottom of Preview) */}
        <div
          className="resizeHandle"
          role="separator"
          aria-label="Resize front preview height"
          title="Drag to resize front preview"
          onPointerDown={(ev) => {
            ev.preventDefault();
            const root = document.documentElement;
            const style = getComputedStyle(root);
            const planH = parseFloat(style.getPropertyValue("--planH")) || 320;
            const canvasTop = (ev.currentTarget as HTMLElement).closest('.canvasStack')?.getBoundingClientRect().top || 0;
            const min = 120;
            const max = 1200;

            const onMove = (mev: PointerEvent) => {
              const y = mev.clientY;
              const newH = Math.max(min, Math.min(max, y - (canvasTop + planH)));
              root.style.setProperty("--previewH", `${newH}px`);
            };

            const onUp = () => {
              window.removeEventListener('pointermove', onMove);
              window.removeEventListener('pointerup', onUp);
            };

            window.addEventListener('pointermove', onMove);
            window.addEventListener('pointerup', onUp);
            (ev.target as Element).setPointerCapture(ev.pointerId);
          }}
        />
      </div>
    </PanelFrame>
  );
}

